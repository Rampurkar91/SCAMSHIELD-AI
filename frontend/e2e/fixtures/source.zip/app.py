eval(user_input)
# Intentionally vulnerable static test fixture. Never execute.
